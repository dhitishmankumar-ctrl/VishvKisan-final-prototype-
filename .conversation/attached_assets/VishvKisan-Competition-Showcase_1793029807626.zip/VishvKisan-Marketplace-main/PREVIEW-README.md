# VishvKisan Competition Showcase

This ZIP keeps the original Replit workspace and adds a small guided competition-showcase panel to the standalone VishvKisan HTML preview.

## Main preview file
Open `artifacts/vishvkisan/index.html` to inspect the standalone showcase page. For full project behavior, use the Vite project rather than opening the HTML as a local file.

## Build settings for a hosting platform
- Project/workspace root: repository root (`VishvKisan-Marketplace-main`)
- Install: `pnpm install`
- Build: `pnpm --filter @workspace/vishvkisan run build` (if the host supports pnpm workspaces)
- App directory: `artifacts/vishvkisan`
- Vite output directory: `artifacts/vishvkisan/dist`

Some hosts do not support this Replit-oriented pnpm workspace without adjustment. If the host requires the app folder as root, dependencies may need to be installed from the workspace root first.

## Showcase panel
The floating **Competition showcase** button opens a guided walkthrough with links to farmer tools, marketplace, order tracking and government schemes. Figures and AI/market/weather examples are illustrative; this is a prototype and does not make real payments or provide a verified AI diagnosis.

Your original GitHub repository is not changed by this ZIP.
