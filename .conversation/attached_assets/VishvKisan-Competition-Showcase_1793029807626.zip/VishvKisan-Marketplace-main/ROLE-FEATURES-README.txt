VISHVKISAN AI ROLE-SPECIFIC SHOWCASE

This ZIP is a separate prototype copy. It does not modify your GitHub repository.

Role placement:
- Farmer Login: Smart Farm Tools, crop photo check (demo), farmer assistant, and smart crop recommendation.
- Customer Login: marketplace and order tracking / My Orders.
- Both roles: language preference selector with English, Assamese, and Hindi showcase options.

Important: This is a showcase prototype. Crop-health notes and crop recommendations are simulated guidance, not real AI diagnosis. Order data and profile data are browser-demo data. The language selector demonstrates selection but does not translate every screen.

For a Vite deployment, use the project root/workspace instructions already included in the project. The actual website entry file is artifacts/vishvkisan/index.html.
